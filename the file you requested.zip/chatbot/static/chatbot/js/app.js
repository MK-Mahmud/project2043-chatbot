/* =====================================================
   ABC BANK SMARTASSIST
   Frontend Controller
===================================================== */

"use strict";

/* ==========================================
   GLOBAL ELEMENTS
========================================== */

const conversation =
    document.getElementById("conversation");

const messageBox =
    document.getElementById("message");

const sendButton =
    document.getElementById("sendBtn");

const loading =
    document.getElementById("loading");

/* ==========================================
   INITIALIZATION
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        scrollConversation();

        enableEnterToSend();

    }
);

/* ==========================================
   AUTO SCROLL
========================================== */

function scrollConversation() {

    if (conversation) {

        conversation.scrollTop =
            conversation.scrollHeight;

    }

}

/* ==========================================
   QUICK QUESTIONS
========================================== */

function setQuestion(question) {

    messageBox.value = question;

    messageBox.focus();

}

/* ==========================================
   SHOW LOADING
========================================== */

function showLoading() {

    if (loading) {

        loading.style.display = "block";

    }

    if (sendButton) {

        sendButton.disabled = true;

        sendButton.innerHTML =
            "Sending...";

    }

}

/* ==========================================
   ENTER TO SEND
========================================== */

function enableEnterToSend() {

    if (!messageBox) {

        return;

    }

    messageBox.addEventListener(
        "keydown",
        function (event) {

            if (
                event.key === "Enter" &&
                !event.shiftKey
            ) {

                event.preventDefault();

                if (
                    messageBox.value.trim() !== ""
                ) {

                    document.querySelector("form")
                        .requestSubmit();

                }

            }

        }
    );

}

/* ==========================================
   SPEECH RECOGNITION
========================================== */

function startListening() {

    if (
        !(
            "webkitSpeechRecognition"
            in window
        )
    ) {

        alert(
            "Speech Recognition is not supported in this browser."
        );

        return;

    }

    const recognition =
        new webkitSpeechRecognition();

    recognition.lang = "en-US";

    recognition.interimResults = false;

    recognition.maxAlternatives = 1;

    recognition.start();

    recognition.onstart = function () {

        console.log(
            "Voice recognition started."
        );

    };

    recognition.onresult = function (event) {

        messageBox.value =
            event.results[0][0].transcript;

    };

    recognition.onerror = function (event) {

        console.log(event.error);

    };

    recognition.onend = function () {

        console.log(
            "Voice recognition ended."
        );

    };

}
/* ==========================================
   TEXT TO SPEECH
========================================== */

function speakResponse() {

    if (!("speechSynthesis" in window)) {

        alert(
            "Text-to-Speech is not supported in this browser."
        );

        return;

    }

    const responses =
        document.getElementsByClassName(
            "bot-response"
        );

    if (responses.length === 0) {

        return;

    }

    const lastResponse =
        responses[
            responses.length - 1
        ].innerText;

    speechSynthesis.cancel();

    const speech =
        new SpeechSynthesisUtterance();

    speech.text = lastResponse;

    speech.lang = "en-US";

    speech.rate = 1;

    speech.pitch = 1;

    speech.volume = 1;

    speech.onstart = function () {

        console.log(
            "Reading response..."
        );

    };

    speech.onend = function () {

        console.log(
            "Speech completed."
        );

    };

    speech.onerror = function (event) {

        console.log(event.error);

    };

    speechSynthesis.speak(speech);

}

/* ==========================================
   STOP SPEAKING
========================================== */

function stopSpeaking() {

    if ("speechSynthesis" in window) {

        speechSynthesis.cancel();

    }

}

/* ==========================================
   CLEAR MESSAGE BOX
========================================== */

function clearInput() {

    if (messageBox) {

        messageBox.value = "";

        messageBox.focus();

    }

}

/* ==========================================
   FORM SUBMISSION
========================================== */

const chatForm =
    document.querySelector("form");

if (chatForm) {

    chatForm.addEventListener(
        "submit",
        function () {

            showLoading();

        }
    );

}

/* ==========================================
   WINDOW LOAD
========================================== */

window.addEventListener(
    "load",
    function () {

        scrollConversation();

    }
);

/* ==========================================
   WINDOW RESIZE
========================================== */

window.addEventListener(
    "resize",
    function () {

        scrollConversation();

    }
);

/* ==========================================
   PAGE VISIBILITY
========================================== */

document.addEventListener(
    "visibilitychange",
    function () {

        if (document.hidden) {

            stopSpeaking();

        }

    }
);

/* ==========================================
   FUTURE UTILITIES
========================================== */

function showNotification(message) {

    console.log(message);

}

function disableSendButton() {

    if (sendButton) {

        sendButton.disabled = true;

    }

}

function enableSendButton() {

    if (sendButton) {

        sendButton.disabled = false;

        sendButton.innerHTML = "📤 Send";

    }

}

function hideLoading() {

    if (loading) {

        loading.style.display = "none";

    }

}

/* ==========================================
   SAFETY TIMER

   Prevents the interface from remaining
   permanently disabled if an unexpected
   error occurs.
========================================== */

setTimeout(function () {

    hideLoading();

    enableSendButton();

}, 15000);

/* ==========================================
   END OF FILE
========================================== */