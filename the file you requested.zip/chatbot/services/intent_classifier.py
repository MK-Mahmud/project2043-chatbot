import joblib
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "intent_model.pkl")

model = joblib.load(MODEL_PATH)


def classify_intent(message):

    prediction = model.predict([message])

    return prediction[0]