def format_response(intent, answer):

    return answer